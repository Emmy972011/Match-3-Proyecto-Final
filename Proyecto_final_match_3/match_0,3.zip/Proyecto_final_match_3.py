import pygame
import random

#GlobaL Variables

list_colors = { 1 :"red.png",               #Uses gem.color method to change sprite
                2 :"orange.png",
                3 :"yellow.png",
                4 :"green.png",
                5 :"blue.png",
                6 :"purple.png",
                0 :"special.png"
                }

list_selected = {   1 :"red_s.png",
                    2 :"orange_s.png",
                    3 :"yellow_s.png",
                    4 :"green_s.png",
                    5 :"blue_s.png",
                    6 :"purple_s.png",
                    0 :"special_s.png"
                    }

list_swapped = {    1 :"red_b.png",         #Visual reference for the gems being swapped
                    2 :"orange_b.png",
                    3 :"yellow_b.png",
                    4 :"green_b.png",
                    5 :"blue_b.png",
                    6 :"purple_b.png",
                    0 :"special_b.png"
                    }


list_grid = []
contadorX = 0
contadorY = 0
list_gem = []
n_pos = 50

gem_horizontal_pop2 = []
gem_vertical_pop2 = []
gem_horizontal_pop1 = []
gem_vertical_pop1 = []

ID_gem = 1

gem_compx = 0
gem_comp_color1 = 0
gem_comp_color2 = 0
gem_compy = 0
gem_comp_ID1 = 0
gem_comp_ID2 = 0

selection = False
pos_x = 0
pos_y = 0

class grid_background():                        #Creates grid instance
    def __init__(self):
        self.image = pygame.image.load("grid.png")
        self.rect = self.image.get_rect()
        self.rect.x = 0
        self.rect.y = 0
      
class gem_instance():                           #Creates gem instance
    def __init__(self):
        self.ID = 0
        self.image = pygame.image.load("test.png")
        self.rect = self.image.get_rect()
        self.rect.x = 0
        self.rect.y = 0
        self.actual_color = 0
        self.clicked = False
        self.dummy = 1

    def gem_swap(self):                                         #If gem swap is sucessful list changes to represent both gems being swapped
        self.image = pygame.image.load(list_swapped[self.actual_color])

    def color_gem(self, color):                             #Changes color of instance, imports parameter color integer and asociates with string...
        self.image = pygame.image.load(list_colors[color])  #see list_colors for details
        self.actual_color = color                           #Sets color value for diferent color variations

    def gem_clicked(self):                                  #Doesn´t change color, changes sprite list to visualize selection, uses color member as key for color
        self.clicked = True                                 #Sets value to clicked
        self.image = pygame.image.load(list_selected[self.actual_color])    ##see list_selected for details
    
    def gem_unclick(self):                                  #unselects current gem and reassigns  "list_colors"
        self.clicked = False
        self.image = pygame.image.load(list_colors[self.actual_color])


def grid_place():                               #CREATES AND PLACES grid background
    global contadorY
    global contadorX
    while contadorY < 250:
        contadorX = 0
        while contadorX < 250:            
            grid_back = grid_background()
            grid_back.rect.x = contadorX
            grid_back.rect.y = contadorY
            list_grid.append(grid_back)
            contadorX += 50
        contadorY += 50

def draw_grid():                                #Draws grid
    for grid_back1 in list_grid:
        screen.blit(grid_back1.image, grid_back1.rect)

def gems_place():                               #CREATES AND PLACES gems
    global ID_gem
    contadorY = 0
    while contadorY < 250:
        contadorX = 0
        while contadorX < 250:            
            gem = gem_instance()                #Creates gem
            gem.ID = ID_gem                     #Assigns ID
            ID_gem += 1
            gem.rect.x = contadorX              #Assigns position
            gem.rect.y = contadorY
            gem.color_gem(6) #Randomly assigns color using class method color gem
            list_gem.append(gem)                #Appends to list
            contadorX += 50
        contadorY += 50

def scramble_gems():                            #scrambles already existing gems
    for gem in list_gem:
        gem.color_gem(random.randint(1, 6))

def unselect_gems():                            #Unselects gems and sets previous selection to false, uses class method "Unclick"
    global selection
    selection = False
    for gem in list_gem:
        gem.gem_unclick()

def draw_gem():                                 #Draws current state of gems
    for gem in list_gem:
        screen.blit(gem.image, gem.rect)

def update_screen():                            #Uses combinations of functions to update the screen
    screen.fill((0, 0, 0))
    grid_place()
    draw_grid()
    draw_gem()
    pygame.display.flip()

def match3_checker(gem):                        #Algorithm for checking match 3 every time a gem was sucessfully swapped
    global n_pos
    global selection, gem_compx, gem_compy, gem_comp_color1
    gem_vertical_pop2.clear()
    gem_horizontal_pop2.clear()
    gem_horizontal_pop2.append(gem.dummy)       #Dummy member in gem class is used to obtain number matchable gems
    gem_vertical_pop2.append(gem.dummy)
    gem_vertical_pop1.clear()
    gem_horizontal_pop1.clear()
    gem_horizontal_pop1.append(gem.ID)          #Obtains ID of gems in case of being matchable
    gem_vertical_pop1.append(gem.ID)
    for gem1 in list_gem:
        n_pos = 50
        if (gem_compy == gem1.rect.y and (gem_compx == (gem1.rect.x + n_pos))) and (gem1.actual_color == gem_comp_color1):      #Scans every side for posible matches
            gem1.gem_clicked()
            gem_horizontal_pop2.append(gem1.dummy)
            gem_horizontal_pop1.append(gem1.ID)
            HP = True
            while(HP == True):                                                                                                  #If a match is found this function scans more matches in the same direction  
                HP = check_adyacent_h_plus()                                                                                    #until a different color gem is found, exits the loop
        elif (gem_compy == gem1.rect.y and (gem_compx == (gem1.rect.x - n_pos))) and (gem1.actual_color == gem_comp_color1):    #Repeats process for each side
            gem1.gem_clicked()
            gem_horizontal_pop2.append(gem1.dummy)
            gem_horizontal_pop1.append(gem1.ID)
            HM = True
            while(HM == True):
                HM = check_adyacent_h_minus()
        elif (gem_compx == gem1.rect.x and (gem_compy == (gem1.rect.y + n_pos))) and (gem1.actual_color == gem_comp_color1):
            gem1.gem_clicked()
            gem_vertical_pop2.append(gem1.dummy)
            gem_vertical_pop1.append(gem1.ID)
            VP = True
            while(VP == True):
                VP = check_adyacent_v_plus()
        elif (gem_compx == gem1.rect.x and (gem_compy == (gem1.rect.y - n_pos))) and (gem1.actual_color == gem_comp_color1):
            gem1.gem_clicked()
            gem_vertical_pop2.append(gem1.dummy)
            gem_vertical_pop1.append(gem1.ID)
            VM = True
            while(VM == True):
                VM = check_adyacent_v_minus()
        else:            
            continue
    print(gem_horizontal_pop2.count(1))
    print(gem_vertical_pop2.count(1))

    if gem_horizontal_pop2.count(1) < 3:                 #If less than 3 gems are matched on an axis the axis list is cleared before exiting the function
         gem_horizontal_pop1.clear()
         print(gem_horizontal_pop1)
    if gem_vertical_pop2.count(1) < 3:
        gem_vertical_pop1.clear()
        print(gem_vertical_pop1)
    pass


def check_adyacent_h_plus():
    global n_pos
    global gem_compy, gem_comp_color1
    n_pos += 50
    for gem in list_gem:
        if (gem_compy == gem.rect.y and (gem_compx == (gem.rect.x + n_pos))) and (gem.actual_color == gem_comp_color1):
            gem.gem_clicked()
            gem_horizontal_pop2.append(gem.dummy)
            gem_horizontal_pop1.append(gem.ID)
            return True
    return False
    pass

def check_adyacent_h_minus():
    global n_pos
    global gem_compy, gem_comp_color1
    n_pos += 50
    for gem in list_gem:
        if (gem_compy == gem.rect.y and (gem_compx == (gem.rect.x - n_pos))) and (gem.actual_color == gem_comp_color1):
            gem.gem_clicked()
            gem_horizontal_pop2.append(gem.dummy)
            gem_horizontal_pop1.append(gem.ID)
            return True
    return False
    pass

def check_adyacent_v_plus():
    global n_pos
    global gem_compy, gem_comp_color1
    n_pos += 50
    for gem in list_gem:
        if (gem_compx == gem.rect.x and (gem_compy == (gem.rect.y + n_pos))) and (gem.actual_color == gem_comp_color1):
            gem.gem_clicked()
            gem_vertical_pop2.append(gem.dummy)
            gem_vertical_pop1.append(gem.ID)
            return True
    return False
    pass

def check_adyacent_v_minus():
    global n_pos
    global gem_compy, gem_comp_color1
    n_pos += 50
    for gem in list_gem:
        if (gem_compx == gem.rect.x and (gem_compy == (gem.rect.y - n_pos))) and (gem.actual_color == gem_comp_color1):
            gem.gem_clicked()
            gem_vertical_pop2.append(gem.dummy)
            gem_vertical_pop1.append(gem.ID)
            return True
    return False
    pass

def precompare_gem(gem):                    #Stores values of selected gem before swapping
    global selection
    global gem_compx, gem_compy, gem_comp_ID1, gem_comp_color1
    selection = True
    gem_compx = gem.rect.x
    gem_compy = gem.rect.y
    gem_comp_ID1 = gem.ID
    gem_comp_color1 = gem.actual_color
    pass

def swap_gem(gem):                          #Stores values of the second gem selected, then swaps values for the first ones
    gem_comp_color2 = gem.actual_color
    gem.color_gem(gem_comp_color1)
    gem.gem_swap()
    for gem in list_gem:
        if gem.ID == gem_comp_ID1:
            gem.color_gem(gem_comp_color2)
            gem.gem_swap()            
            update_screen()
            pygame.time.delay(300)
    pass
    
def pop_gem(list):                          #Removes gems after match 3
    for id in list:
        for gem in list_gem:
            if gem.ID == id:
                list_gem.remove(gem)
    pass



pygame.init()
screen = pygame.display.set_mode((640, 480))
frame_rate = pygame.time.Clock()
game_over = False

screen.fill((0, 0, 0))
    
grid_place()
draw_grid()
gems_place()
draw_gem()

while not game_over:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_over = True
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            game_over = True
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 2:
                pos = pygame.mouse.get_pos()
                for gem in list_gem:
                    if gem.rect.collidepoint(pos):
                        gem.color_gem(random.randint(1, 6))
            if event.button == 3:
                scramble_gems()
            if event.button == 1:
                pos = pygame.mouse.get_pos()               
                print(selection)
                if selection == False:
                    for gem in list_gem:
                        if gem.rect.collidepoint(pos):
                            if gem.clicked == False:
                                gem.gem_clicked()
                                precompare_gem(gem)                                
                            else:
                                unselect_gems()                        
                elif selection == True:
                    for gem in list_gem:
                        if gem.rect.collidepoint(pos):                            
                            if gem.clicked == False:
                                if (((gem.rect.x) == (gem_compx + 50)) and ((gem.rect.y) < (gem_compy + 50) and (gem.rect.y) > (gem_compy - 50))) or (((gem.rect.x) == (gem_compx - 50)) and ((gem.rect.y) < (gem_compy + 50) and (gem.rect.y) > (gem_compy - 50))):
                                    swap_gem(gem)
                                    precompare_gem(gem)
                                    unselect_gems()
                                    match3_checker(gem)
                                    update_screen()
                                    pygame.time.delay(300)
                                    pop_gem(gem_horizontal_pop1)
                                    pop_gem(gem_vertical_pop1)
                                    unselect_gems()
                                    break
                                if (((gem.rect.y) == (gem_compy + 50)) and ((gem.rect.x) < (gem_compx + 50) and (gem.rect.x) > (gem_compx - 50))) or (((gem.rect.y) == (gem_compy - 50)) and ((gem.rect.x) < (gem_compx + 50) and (gem.rect.x) > (gem_compx - 50))):
                                    swap_gem(gem)
                                    precompare_gem(gem)
                                    unselect_gems()
                                    match3_checker(gem)
                                    update_screen()
                                    pygame.time.delay(300)
                                    pop_gem(gem_horizontal_pop1)
                                    pop_gem(gem_vertical_pop1)
                                    unselect_gems()
                                    continue
                                else:
                                    unselect_gems()
                            else:
                                unselect_gems()

    update_screen()
    frame_rate.tick(60)